import java.util.Scanner;

public class votingSystem {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

//        int num1 = scanner.nextInt();
//        switch (num1){
//            case 1:
//                System.out.println("Sunday");
//                break;
//            case 2:
//                System.out.println("Monday");
//                break;
//            case 3:
//                System.out.println("Tuesday");
//                break;
//            case 4:
//               System.out.println("Wednesday");
//                break;
//            case 5:
//                System.out.println("thursday");
//                break;
//            case 6:
//                System.out.println("Friday");
//                break;
//            case 7:
//              System.out.println("Saturday");
//                break;
//
//                default:
//            System.out.println("invalid input");
//        }


        System.out.println(" ");
        System.out.println("  WELCOME TO MY ONLINE VOTING TEST CLICK TO CONTINUE");
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            System.console().readLine();

        String name = System.console().readLine("  What is your name please: ");
            System.out.println(" OK! your name is " + name);
            System.out.println("====================================================>>");

            System.out.println("  How do you want me to address u (Mr or Madam)");
            String sex = System.console().readLine();

        String CurrentYear = System.console().readLine(sex +" " + name +" kindly enter the Current year we are in to: ");
            System.out.println("You entered " + CurrentYear);
             System.out.println("==================================================>>");

        String DateOfBirth = System.console().readLine(sex + " " + name +" what is your date of birth? only year ");
            System.out.println("You entered " + DateOfBirth);
        System.out.println("============================================>>");

        int age = Integer.parseInt(CurrentYear) - Integer.parseInt(DateOfBirth);

            System.out.println("your age is " + age);
        if (age < 18 ){
            System.out.println("sorry u can not vote");
        } else if (age >= 18) {
            System.out.println("Congratulations " +sex + " "+ name +" you are qualify to vote");
            System.out.println("=====================================>>");

        }else {
            System.out.println("RESULT NOT FOUND please check you input correctly");
        }
    }
    }




