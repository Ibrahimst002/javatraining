public class forLoopC {
    public static void main(String[] args) {
        int countofmatch =0;
        int sumofmatch = 0;
        for (int loopnumber = 1; loopnumber <= 1000; loopnumber++){
            if((loopnumber % 3 == 0) && (loopnumber % 5 ==0 )){
                countofmatch++;
                sumofmatch += loopnumber;
                System.out.println("the matching value " + loopnumber);
            }
            if ( countofmatch ==5){
               break;
            }
        }
        System.out.println("sum of matching numbers " + sumofmatch);
    }
}
