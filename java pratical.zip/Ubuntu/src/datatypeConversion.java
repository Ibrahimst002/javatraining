public class datatypeConversion {
    public static void main(String[] args) {
        String currentYear = "2024";
        String dateOfBirth = "2015";
        int year = Integer.parseInt(currentYear);
        int birth = Integer.parseInt(dateOfBirth);
        int age = year - birth;
        System.out.println("the current year is " + currentYear);
        System.out.println("your  date of birth is " + dateOfBirth);
        System.out.println("Your age is " + age);

        if(age < 18){
            System.out.println( " the input date is " + age + " You can not vote this year");
        } else if (age >= 18) {
            System.out.println( " the input date is " + age + " You passed the requirement, You can vote ");
        } else {
            System.out.println("wrong input");
        }
    }
}
