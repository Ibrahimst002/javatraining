import java.util.Scanner;

public class scannerTraining {



    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
//        int CurrentYear = 2022;
//        try{
//            System.out.println(getinputFromScanner(CurrentYear));
//        }catch (NullPointerException e){
//            System.out.println(getinputFromScanner(CurrentYear));
//        }
//
//    }
//    public static String getinputFromScanner( int CurrentYear){
//
//        Scanner scanner = new Scanner(System.in);
//
//        System.out.println("what is your name");
//        String name = scanner.nextLine();
//        System.out.println(name);
//
//        System.out.println("what is your date of birth? year only");
//        String dateOfBirth = scanner.nextLine();
//        int age =  CurrentYear - Integer.parseInt(dateOfBirth) ;
//        return "Your age is " + age;

        System.out.println(" please enter your name");
        String name = scanner.nextLine();

            System.out.println("enter your date of birth");

            int dateOfBirth = scanner.nextInt();
            int year = 2024;
            int age =  year - dateOfBirth;
            System.out.println(age);

    }
}
