public class mOverloadingChallenge {
    public static void main(String[] args) {
        convertToCementers(5);
        convertToCementers(5,8);
        System.out.println("5ft, 8in= " + convertToCementers(5,8) + "cm");
        System.out.println("68in = " + convertToCementers(68) + "cm");
    }
    public static double convertToCementers(int inches){
        return inches * 2.54;
    }
    public static double convertToCementers(int feet, int inches){

        return convertToCementers((feet * 12) + inches);
    }

}
