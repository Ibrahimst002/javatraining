public class weezyChallenge {
    public static void main(String[] args) {

        for(int num1 = 1; num1 <= 100; num1++){

             if (num1 % 4 ==0 && num1 % 6 ==0){

            System.out.println("Computer Software");
        }
            else if (num1 % 4 ==0) {
                System.out.println("computer");
            }
          else if (num1 % 6 == 0){
               System.out.println("Software");
            }
        else {
               System.out.println("University");
           }
        }
    }

}
