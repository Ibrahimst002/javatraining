public class whileLoop {
    public static void main(String[] args) {
//        int j = 1;
//        while (true){
//           if(j <= 5){
//                System.out.println(j);
//                j++;
//            }
//        }
//        int z = 1;
//        while (z <= 5){
//            System.out.println(z);
//            z++;
//        }
        int num1 =4;
        int oddCount = 0;
        int evenCount = 0;
        while (num1 <= 20){
            num1++;
            if (!isEvenNumber(num1)){
                oddCount++;
                continue;
            }
            System.out.println(num1);
                evenCount++;
                if (evenCount >= 5){
                    break;
                }
        }

        System.out.println("total odd count " + oddCount);
        System.out.println("total even count " + evenCount);

    }
    public static boolean isEvenNumber(int num1){
        if ((num1 % 2) == 0){
            return true;

        }else {
            return false;
        }

    }
}
