public class forLoop {
    public static void main(String[] args) {
//        System.out.println("2 is " + (findPrimeNumber(2) ? "" : "NOT ")+ "a prime number");
//        System.out.println("3 is " + (findPrimeNumber(3) ? "" : "NOT ")+ "a prime number");
//        System.out.println("4 is " + (findPrimeNumber(4) ? "" : "NOT ")+ "a prime number");
//        System.out.println("5 is " + (findPrimeNumber(5) ? "" : "NOT ")+ "a prime number");
//        System.out.println("6 is " + (findPrimeNumber(6) ? "" : "NOT ")+ "a prime number");
//        System.out.println("7 is " + (findPrimeNumber(7) ? "" : "NOT ")+ "a prime number");
//    }
//    public static boolean findPrimeNumber(int number){
//        if(number <= 2) {
//            return (number == 0);
//        }for (int divide = 2; divide < number; divide++){
//                if (number % 2 == 0){
//                    return false;
//                }
//            }
//        return true;
//        int count = 0;
//        for(int rangeofNumber =10; rangeofNumber <= 1000; rangeofNumber++){
//
//        if (rangeofNumber % 2 >= 1) {
//                System.out.println(  rangeofNumber + " is a prime number");
//
//           if (rangeofNumber >=1);
//            count++;
//            if (count == 3){
//                System.out.println("end of looping");
//               break;
//            }
//            }else {
//                System.out.println("");
//            }
//        }
        int count = 0;
        int sum = 0;
        for (int number = 1; number <= 1000; number++){
            if ((number % 3 == 0) && (number % 5 ==0)){
               count++;
               sum += number;
                System.out.println(number);

            }
            if(count == 5){
                break;
            }


        }
        System.out.println("sum = " + sum);
    }
}

