public class MethodOverloading {
    public static void main(String[] args) {
        cal("Ibrahim", 28);
        cal("rapasco", 16, 'F');
        int num33=calt(10, 20,36);

System.out.println(num33);

    }

    public static void cal(String name, int age) {
        if (age <= 17) {
            System.out.println("young");
        } else if (age >= 18 && age >= 50) {
            System.out.println("is an adult and below 50");
        } else if (age > 50) {
            System.out.println(" is above 50");
        } else if (age >= 18 && age < 50) {
            System.out.println("he is an adult who is below 50");
        }

    }

    public static void cal(String name, int age, char sex) {
        if (sex == 'M') {
            System.out.println("he is a male");
        } else if (sex == 'F') {
            System.out.println("he is a female");
        } else {
            System.out.println("cant say");
        }

    }

    public static int calt(int num1, int num2, int num3) {

        return num3 = num1 + num2;

    }

}
